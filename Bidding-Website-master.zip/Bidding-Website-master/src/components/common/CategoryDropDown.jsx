import Select from "react-select";

export const CategoryDropDown = (props) => {
  return (
    <>
      <Select id="category" />
    </>
  );
};
